#ifndef BOOL_H
#define BOOL_H

typedef int bool;
const int false = 0;
const int true = 1;

#endif
